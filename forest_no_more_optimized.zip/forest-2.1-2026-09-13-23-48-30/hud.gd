extends CanvasLayer

var _fps_update_interval: float = 0.2
var _fps_timer: float = 0.0

func _ready() -> void:
	$CoinsLabel.text = str(0)
	$FPSLabel.text = "FPS: 0"

func update_score(new_score: int) -> void:
	$CoinsLabel.text = str(new_score)

func _process(delta: float) -> void:
	_fps_timer += delta
	if _fps_timer >= _fps_update_interval:
		_fps_timer = 0.0
		$FPSLabel.text = "FPS: " + str(Engine.get_frames_per_second())
