extends Node3D

@export var coin_scene: PackedScene
@export var max_active_coins: int = 100
@export var coin_lifetime: float = 30.0  # seconds before an uncollected coin despawns

@onready var timer: Timer = $Timer
@onready var spawn_zone: Area3D = $SpawnZone
@onready var collision_shape: CollisionShape3D = $SpawnZone/CollisionShape3D

var active_coins: Array[Node] = []

func _ready() -> void:
	timer.timeout.connect(_on_timer_timeout)

func _on_timer_timeout() -> void:
	spawn_coin()

func spawn_coin() -> void:
	if coin_scene == null:
		print("Warning: Assign a coin scene in the Inspector!")
		return

	# Clean up any freed references before checking the cap
	active_coins = active_coins.filter(func(c): return is_instance_valid(c))

	if active_coins.size() >= max_active_coins:
		return

	var box_shape = collision_shape.shape as BoxShape3D
	if not box_shape:
		print("Warning: CollisionShape3D needs a BoxShape3D assigned!")
		return

	var box_size = box_shape.size

	# Calculate random position inside the collision box
	var random_x = randf_range(-box_size.x / 2.0, box_size.x / 2.0)
	var random_y = randf_range(0, box_size.y / 2.0)
	var random_z = randf_range(-box_size.z / 2.0, box_size.z / 2.0)
	var local_random_pos = Vector3(random_x, random_y, random_z)

	# Transform local offset to global coordinate space
	var target_world_pos = spawn_zone.global_transform * local_random_pos

	# Instantiate and place BEFORE adding to the tree
	var coin_instance = coin_scene.instantiate()
	coin_instance.transform.origin = target_world_pos
	add_child(coin_instance)

	active_coins.append(coin_instance)

	
