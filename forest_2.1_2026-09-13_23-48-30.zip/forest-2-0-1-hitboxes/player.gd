extends CharacterBody3D

signal score_changed(new_score: int)

@export_group("Movement")
@export var walk_speed: float = 7.0
@export var sprint_speed: float = 20.0
@export var jump_velocity: float = 6.0
@export var air_drag: float = 3.0
@export var mouse_sensitivity: float = 0.003

@export_group("Pickup System")
@export var score: int = 0

@onready var camera: Camera3D = $Camera3D
@onready var pickup_area: Area3D = $PickupArea

var gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity")


func _ready() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

	if camera:
		camera.rotation = Vector3.ZERO

	if pickup_area:
		pickup_area.area_entered.connect(_on_pickup_area_entered)


func _unhandled_input(event: InputEvent) -> void:
	# Recapture mouse
	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_LEFT:
			Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

	# First-person mouse look
	if event is InputEventMouseMotion:
		if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
			rotate_y(-event.relative.x * mouse_sensitivity)

			if camera:
				camera.rotate_x(-event.relative.y * mouse_sensitivity)
				camera.rotation.x = clamp(
					camera.rotation.x,
					deg_to_rad(-89.0),
					deg_to_rad(89.0)
				)


func _physics_process(delta: float) -> void:
	# Gravity
	if not is_on_floor():
		velocity.y -= gravity * delta

	# Jump
	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = jump_velocity

	# Movement input
	var input_dir := Input.get_vector(
		"move_left",
		"move_right",
		"move_forward",
		"move_back"
	)

	var direction := (
		transform.basis * Vector3(input_dir.x, 0, input_dir.y)
	).normalized()

	# Air movement
	if not is_on_floor():
		if direction != Vector3.ZERO:
			velocity.x = move_toward(
				velocity.x,
				direction.x * sprint_speed,
				air_drag * delta
			)

			velocity.z = move_toward(
				velocity.z,
				direction.z * sprint_speed,
				air_drag * delta
			)
	else:
		# Ground movement
		var current_speed: float = (
			sprint_speed
			if Input.is_action_pressed("sprint")
			else walk_speed
		)

		if direction != Vector3.ZERO:
			velocity.x = direction.x * current_speed
			velocity.z = direction.z * current_speed
		else:
			velocity.x = move_toward(
				velocity.x,
				0.0,
				current_speed
			)

			velocity.z = move_toward(
				velocity.z,
				0.0,
				current_speed
			)

	move_and_slide()


func _on_pickup_area_entered(area: Area3D) -> void:
	if area.is_in_group("collectible"):
		score += 1
		print("Item collected! Current Score: ", score)
		score_changed.emit(score)
		area.queue_free()
