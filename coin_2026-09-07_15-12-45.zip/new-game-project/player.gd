extends RigidBody3D

@export var move_speed: float = 10.0
@export var mouse_sensitivity: float = 0.001
@export var max_pitch: float = 1.5
@export var jump_force: float = 8.0

var twist_input: float = 0.0
var pitch_input: float = 0.0


func _ready() -> void:
	add_to_group("player")
	Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)


func _physics_process(_delta: float) -> void:
	var input: Vector3 = Vector3.ZERO

	# Movement
	input.x = Input.get_axis("move_left", "move_right")
	input.z = Input.get_axis("move_forward", "move_back")

	input = input.normalized()

	var direction: Vector3 = $TwistPivot.global_transform.basis * input

	linear_velocity.x = direction.x * move_speed
	linear_velocity.z = direction.z * move_speed

	# Jump
	if Input.is_action_just_pressed("Jump"):
		apply_central_impulse(Vector3.UP * jump_force)


func _process(_delta: float) -> void:
	# Look left/right
	$TwistPivot.rotate_y(twist_input)

	# Look up/down
	$TwistPivot/PitchPivot.rotate_x(pitch_input)

	# Limit vertical camera rotation
	$TwistPivot/PitchPivot.rotation.x = clamp(
		$TwistPivot/PitchPivot.rotation.x,
		-max_pitch,
		max_pitch
	)

	# Reset mouse input
	twist_input = 0.0
	pitch_input = 0.0

	# Escape releases mouse
	if Input.is_action_just_pressed("ui_cancel"):
		Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion:
		if Input.get_mouse_mode() == Input.MOUSE_MODE_CAPTURED:
			twist_input = -event.relative.x * mouse_sensitivity
			pitch_input = -event.relative.y * mouse_sensitivity
