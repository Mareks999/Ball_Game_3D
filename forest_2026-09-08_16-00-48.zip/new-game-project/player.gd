extends RigidBody3D

@export_category("Movement")
@export var move_speed: float = 10.0
@export var jump_force: float = 8.0

@export_category("Mouse Look")
@export var mouse_sensitivity: float = 0.001
@export var max_pitch: float = 1.5

@onready var twist_pivot: Node3D = $TwistPivot
@onready var pitch_pivot: Node3D = $TwistPivot/PitchPivot


func _ready() -> void:
	add_to_group("player")
	Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)


func _physics_process(_delta: float) -> void:
	handle_movement()
	handle_jump()


func _process(_delta: float) -> void:
	handle_camera()


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion:
		if Input.get_mouse_mode() == Input.MOUSE_MODE_CAPTURED:
			twist_pivot.rotate_y(-event.relative.x * mouse_sensitivity)
			pitch_pivot.rotate_x(-event.relative.y * mouse_sensitivity)

			pitch_pivot.rotation.x = clamp(
				pitch_pivot.rotation.x,
				-max_pitch,
				max_pitch
			)

	if event.is_action_pressed("ui_cancel"):
		Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)


func handle_movement() -> void:
	var input_2d := Input.get_vector(
		"move_left",
		"move_right",
		"move_forward",
		"move_back"
	)

	var input_direction := Vector3(
		input_2d.x,
		0.0,
		input_2d.y
	)

	var direction := twist_pivot.global_transform.basis * input_direction
	direction.y = 0.0
	direction = direction.normalized()

	linear_velocity.x = direction.x * move_speed
	linear_velocity.z = direction.z * move_speed


func handle_jump() -> void:
	if Input.is_action_just_pressed("Jump"):
		apply_central_impulse(Vector3.UP * jump_force)


func handle_camera() -> void:
	# Camera rotation is handled in _unhandled_input().
	pass
