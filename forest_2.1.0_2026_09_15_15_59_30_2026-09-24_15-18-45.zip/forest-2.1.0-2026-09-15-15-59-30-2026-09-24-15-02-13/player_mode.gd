extends Control

func _ready() -> void:
	pass

func _process(delta: float) -> void:
	pass

func _on_single_player_pressed() -> void:
	get_tree().change_scene_to_file("res://Level.tscn")

func _on_multiplayer_pressed() -> void:
	get_tree().change_scene_to_file("res://Level.tscn")

func _on_back_pressed() -> void:
	get_tree().change_scene_to_file("res://main_menu.tscn")
