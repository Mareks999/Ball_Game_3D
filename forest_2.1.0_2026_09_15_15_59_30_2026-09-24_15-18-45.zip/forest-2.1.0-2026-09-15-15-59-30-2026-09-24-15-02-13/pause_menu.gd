extends Control

@onready var main = get_tree().current_scene

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_WHEN_PAUSED


func _on_resume_pressed() -> void:
	main.toggle_pause()

	


func _on_main_menu_pressed() -> void:
	get_tree().paused = false
	Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
	get_tree().change_scene_to_file("res://main_menu.tscn")


func _on_exit_pressed() -> void:
	get_tree().quit()
