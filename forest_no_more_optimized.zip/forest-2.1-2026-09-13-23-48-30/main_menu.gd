extends Control

func _ready() -> void:
	Engine.max_fps = 144

func _on_start_pressed() -> void:
	get_tree().change_scene_to_file("res://Level.tscn")

func _on_options_pressed() -> void:
	print("options")

func _on_exit_pressed() -> void:
	get_tree().quit()
