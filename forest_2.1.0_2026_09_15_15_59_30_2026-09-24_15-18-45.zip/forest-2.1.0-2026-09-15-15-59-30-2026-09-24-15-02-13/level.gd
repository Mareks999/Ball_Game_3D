extends Node3D

signal time_up

@export var round_time: float = 60.0

@onready var pause_menu: Control = $PauseMenu

var paused := false
var time_left: float

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS

	$Player.score_changed.connect($HUD.update_score)

	time_left = round_time
	$HUD.update_timer(time_left)

	get_tree().paused = false
	Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)


func _process(delta: float) -> void:
	if time_left <= 0.0:
		return

	if not paused:
		time_left = max(time_left - delta, 0.0)
		$HUD.update_timer(time_left)

		if time_left == 0.0:
			time_up.emit()
			_on_time_up()

	if Input.is_action_just_pressed("pause"):
		toggle_pause()


func toggle_pause() -> void:
	paused = !paused

	if paused:
		pause_menu.show()
		get_tree().paused = true
		Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
	else:
		pause_menu.hide()
		get_tree().paused = false
		Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)


func _on_time_up() -> void:
	print("Time's up!")
