extends Node3D


func _ready() -> void:
	$Player.score_changed.connect($HUD.update_score)
