extends Node3D

signal time_up

@export var round_time: float = 60.0

var time_left: float


func _ready() -> void:
	$Player.score_changed.connect($HUD.update_score)

	time_left = round_time
	$HUD.update_timer(time_left)


func _process(delta: float) -> void:
	if time_left <= 0.0:
		return

	time_left = max(time_left - delta, 0.0)
	$HUD.update_timer(time_left)

	if time_left == 0.0:
		time_up.emit()
		_on_time_up()


func _on_time_up() -> void:
	print("Time's up!")
	# TODO: hook up whatever "round over" behavior you want here
	# e.g. $CoinSpawner.timer.stop(), disable player input, show a results screen, etc.
