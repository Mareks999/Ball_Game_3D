extends CanvasLayer

var _fps_update_interval: float = 0.2
var _fps_timer: float = 0.0

func _ready() -> void:
	$CoinsLabel.text = str(0)
	$FPSLabel.text = "FPS: 0"
	$TimerLabel.text = _format_time(0.0)

func update_score(new_score: int) -> void:
	GameData.coins = new_score
	$CoinsLabel.text = str(new_score)


func update_timer(seconds_left: float) -> void:
	$TimerLabel.text = _format_time(seconds_left)
	
	
	if seconds_left <= 0.0:
		get_tree().change_scene_to_file("res://gameover.tscn") 

func _format_time(seconds: float) -> String:
	var total := int(ceil(seconds))
	var minutes := total / 60
	var secs := total % 60
	return "%d:%02d" % [minutes, secs]

func _process(delta: float) -> void:
	_fps_timer += delta
	if _fps_timer >= _fps_update_interval:
		_fps_timer = 0.0
		$FPSLabel.text = "FPS: " + str(Engine.get_frames_per_second())
