extends Node

var coins: int = 0
var mouse_sensitivity: float = 0.003
