extends Control

@onready var main_buttons: VBoxContainer = $MainButtons
@onready var options: Panel = $Options


func _ready() -> void:
	main_buttons.visible = true
	options.visible = false
	$Options/Sensitivity.value = GameData.mouse_sensitivity

func _on_start_pressed() -> void:
	get_tree().change_scene_to_file("res://player_mode.tscn")

func _on_options_pressed() -> void:
	main_buttons.visible = false
	options.visible = true
	

func _on_exit_pressed() -> void:
	get_tree().quit()


func _on_back_options_pressed() -> void:
	_ready()
	
func _on_sensitivity_value_changed(value: float) -> void:
	GameData.mouse_sensitivity = value
	




	
