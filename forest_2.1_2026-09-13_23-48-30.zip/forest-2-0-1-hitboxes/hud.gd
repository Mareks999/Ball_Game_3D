extends CanvasLayer


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	$CoinsLabel.text = str(0)


func update_score(new_score: int) -> void:
	$CoinsLabel.text = str(new_score)


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	$FPSLabel.text = "FPS: " + str(Engine.get_frames_per_second())


#https://www.youtube.com/watch?v=zR0sLAGpsIY
