extends Area3D

const ROT_SPEED = 120.0


func _ready() -> void:
	body_entered.connect(_on_body_entered)


func _process(delta: float) -> void:
	rotate_y(deg_to_rad(ROT_SPEED) * delta)


func _on_body_entered(body: Node3D) -> void:
	if body.is_in_group("player"):
		queue_free()
