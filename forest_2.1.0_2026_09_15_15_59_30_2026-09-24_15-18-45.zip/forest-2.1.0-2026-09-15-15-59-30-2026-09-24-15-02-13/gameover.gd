extends Node3D

func _ready() -> void:
	Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
	get_tree().paused = false

	$ScoreLabel.text = "Coins: " + str(GameData.coins)





func _on_button_pressed() -> void:
	get_tree().change_scene_to_file("res://main_menu.tscn")
