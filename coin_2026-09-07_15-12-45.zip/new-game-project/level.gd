extends Node3D

var coins = 0
const NUM_COINS_TO_WIN = 10
